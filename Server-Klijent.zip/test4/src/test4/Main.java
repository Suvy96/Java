package test4;  
 
    public class Main {  
        public static void main(String[] args) {  
          Server s = new Server();  
          Klijent k = new Klijent();  

          s.start();  
          k.start();  

    }  
      
  }  